package jwtc.android.chess.views;

import android.content.Context;
import android.view.View;

public class PGNItemView extends View {

    public PGNItemView(Context context) {
        super(context);
    }
}
