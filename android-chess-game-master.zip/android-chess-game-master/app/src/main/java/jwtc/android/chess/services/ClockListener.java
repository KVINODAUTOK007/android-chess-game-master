package jwtc.android.chess.services;

public interface ClockListener {
    void OnClockTime();
}
