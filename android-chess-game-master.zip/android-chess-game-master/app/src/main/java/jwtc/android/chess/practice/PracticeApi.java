package jwtc.android.chess.practice;

import jwtc.android.chess.services.GameApi;

public class PracticeApi extends GameApi {
}
